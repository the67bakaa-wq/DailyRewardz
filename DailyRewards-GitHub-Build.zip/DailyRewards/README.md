# DailyRewards — Paper 1.21.11

A Java 21 Maven project for a Paper server. The included GitHub Actions workflow builds the plugin without needing Maven on your phone.

## Build with GitHub Actions

1. Create a new GitHub repository.
2. Upload the contents of this folder (including the hidden `.github` folder) to the repository's root.
3. Open the repository's **Actions** tab.
4. Select **Build DailyRewards** and press **Run workflow**. You can also push a commit to `main` or `master` to trigger a build.
5. Open the completed workflow run and download the `DailyRewards` artifact.
6. Extract the artifact; it contains `DailyRewards-1.0.0.jar`.
7. Put the JAR in your server's `plugins` folder and restart the server.

## Local build

Requires Java 21 and Maven. Run `mvn clean package`. The JAR is created at `target/DailyRewards-1.0.0.jar`.

## Commands

- `/daily` — open the player menu
- `/daily claim` — start the reward reveal
- `/daily editor` — open the admin reward editor
- `/daily reload` — reload configuration (admin)
- `/daily reset <player>` — reset an online player's cooldown (admin)

## Permissions

- `dailyrewards.use` (default: true)
- `dailyrewards.admin` (default: op)

## Notes

- Reward weights are configured in `config.yml`; they do not need to add up to 100.
- The winning reward is selected before the reveal animation begins.
- Cooldowns are 24 hours from the claim time and persist in the plugin configuration.
- A reward that does not fit in the inventory is dropped safely at the player's location.
- The editor currently toggles rewards and adjusts their weight. Material and amount are edited in `config.yml`.
